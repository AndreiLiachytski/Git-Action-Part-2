import { LightningElement, track } from 'lwc';

const LABELS = {
    title: '3. Billing information'
}

export default class B2bBillingCheckoutInformation extends LightningElement {

    // ============================ VARIABLES ===========================================

    @track LABELS = LABELS;
}