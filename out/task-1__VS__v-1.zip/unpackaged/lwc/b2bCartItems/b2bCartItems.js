/**
 * Created by Owner on 10/15/2021.
 */

import {LightningElement} from 'lwc';

export default class B2BCartItems extends LightningElement {

}